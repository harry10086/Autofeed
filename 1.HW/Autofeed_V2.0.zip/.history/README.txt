KiCad Local History Directory
=============================

This directory contains automatic snapshots of your project files.
KiCad periodically saves copies of your work here, allowing you to
recover from accidental changes or data loss.

You can browse and restore previous versions through KiCad's
File > Local History menu.

To disable this feature:
  Preferences > Common > Project Backup > Enable automatic backups

This directory can be safely deleted if you no longer need the
history, but doing so will permanently remove all saved snapshots.
